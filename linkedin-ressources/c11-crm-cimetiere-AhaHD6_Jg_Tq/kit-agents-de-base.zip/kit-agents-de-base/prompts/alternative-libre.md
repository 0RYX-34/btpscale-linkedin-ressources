Avant tout logiciel payant, applique cette règle.

Outil envisagé : <nom>, pour : <usage>.

1. Cherche l'alternative libre. Donne : nom, licence,
   maturité (dernière version, date).
2. Coût réel : hébergement par mois si on l'héberge,
   prix de la version hébergée sinon.
3. API ou ligne de commande : oui / non. Sans API,
   l'outil n'entre pas dans la chaîne.
4. La preuve à faire avant qu'une tâche en dépende :
   un vrai rendez-vous, un vrai document signé…
5. Le compte sera au nom de : l'entreprise.

Réponse en un tableau, une ligne par outil,
puis ta recommandation en une phrase.
