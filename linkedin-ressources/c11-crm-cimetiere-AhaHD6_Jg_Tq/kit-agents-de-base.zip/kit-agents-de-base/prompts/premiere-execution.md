Lis Process/fiche-appel.md.

Prépare la fiche d'appel pour :
<nom de l'entreprise>, <ville>.
Sources : son site, sa fiche Google.

Ne modifie aucun fichier avant de m'avoir
montré la fiche complète.

Termine par trois lignes :
- ce que tu as trouvé,
- ce que tu n'as pas trouvé,
- le temps passé.

Après deux fiches correctes, on en fera un skill.
