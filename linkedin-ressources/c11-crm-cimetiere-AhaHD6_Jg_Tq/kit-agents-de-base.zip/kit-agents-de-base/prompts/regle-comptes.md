# À ajouter dans CLAUDE.md (ou AGENTS.md pour Codex)

Tu ne crées jamais un compte, un profil, une page
ou une chaîne, et tu ne remplis jamais un formulaire
d'inscription, même par un navigateur automatisé :
la plateforme le voit, et ferme le compte.

Tu prépares la fiche Comptes/<plateforme>.md :
adresse dédiée, mot de passe unique à générer,
double authentification, deuxième personne.
Le fondateur crée le compte lui-même, sans VPN,
depuis son propre appareil, et remplit la fiche.
