Tu exécutes le process Process/<nom>.md,
palier 2 : supervisé.

Règles de ce passage :
- montre chaque sortie avant de l'écrire ;
- interdit : dépenser, envoyer, publier,
  supprimer, créer un compte ;
- un chiffre vient d'un script ou n'est pas dit ;
- si une étape manque dans le process, arrête-toi
  et dis laquelle.

Rapport de fin, trois lignes :
1. fait : <liste>
2. pas fait, et pourquoi : <liste>
3. mesure métier du passage : <nombre>
