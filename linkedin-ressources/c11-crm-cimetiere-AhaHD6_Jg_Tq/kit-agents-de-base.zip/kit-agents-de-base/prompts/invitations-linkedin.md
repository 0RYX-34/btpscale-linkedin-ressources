Fiche du prospect : <métier>, <ville>, <site>,
<dernière publication>.

Rédige 3 invitations LinkedIn, 200 caractères au
plus chacune, une raison vraie de se connecter,
sans offre, sans « IA », sans lien.

Puis le premier message après acceptation :
3 phrases, une question sur son activité, pas de
lien, pas de rendez-vous proposé.

Je choisis et j'envoie moi-même, depuis mon compte.
Tu n'envoies rien.
