Voici le site de <entreprise> : <adresse>.

Donne un verdict parmi cinq, et rien d'autre :
absent · mort · vitrine sans capture ·
actif avec capture · paie déjà.

Indices à chercher (présence = fiable,
absence = doute, jamais une certitude) :
- un formulaire ou un numéro cliquable ;
- un pixel publicitaire ou un badge de plateforme ;
- des pages par métier et par ville ;
- des avis datés ; l'année de mise à jour.

Réponse : 3 champs de 90 caractères au plus :
site / signes / à dire en premier au téléphone.
