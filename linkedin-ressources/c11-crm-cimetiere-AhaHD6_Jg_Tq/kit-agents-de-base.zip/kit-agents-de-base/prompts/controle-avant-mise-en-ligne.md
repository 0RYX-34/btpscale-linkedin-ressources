Avant mise en ligne du site de <client>, vérifie
et refuse si un point échoue. Réponse : une ligne
par point, OK ou REFUS avec le fichier fautif.

1. Aucune image de démonstration : rien ne vient
   du dossier des gabarits (/demo/, /placeholder/).
2. Aucune promesse de délai plus courte que le
   chantier le plus court affiché sur la même page.
3. Mentions légales complètes : statut, SIRET, TVA,
   médiateur, hébergeur.
4. Aucun bloc « compris / non compris » sans la
   liste correspondante dans client-config.yml.
5. Chaque avis a une source et une date.

Ne corrige rien. Un REFUS bloque la mise en ligne.
