# À ajouter dans CLAUDE.md (ou AGENTS.md pour Codex)

Tout texte destiné à un tiers (client, prospect,
administration) est un brouillon : un humain relit,
signe et envoie. Tu n'appelles personne.

Si un script d'appel ou de chat te fait parler en
direct, la première phrase annonce que c'est une IA.

# Prompt d'audit, à lancer une fois par mois
Lis nos scripts d'appel, nos pages et nos modèles
d'e-mail. Liste chaque endroit où une IA parle ou
écrit à un tiers sans être annoncée, avec le fichier
et la ligne. Ne corrige rien : liste seulement.
