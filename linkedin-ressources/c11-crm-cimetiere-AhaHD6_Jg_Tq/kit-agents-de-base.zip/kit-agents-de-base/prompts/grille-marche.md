Marché à évaluer : <secteur, zone, taille du client>.

Remplis la grille en 4 critères. Pour chacun :
une mesure chiffrée, une source primaire datée
(institut, registre, rapport officiel), un verdict
vert / moyen / rouge.

1. Douleur : le client dit-il lui-même son problème ?
   Cherche 50 témoignages publics avant toute étude.
2. Pouvoir d'achat : la marge du secteur, qui décide.
3. Ciblage : la base publique, le coût d'un contact.
4. Croissance : le chiffre d'affaires sur 3 ans.
   Si rouge : mesure le taux d'équipement.

Un critère sans mesure vaut rouge. N'invente
aucun chiffre : écris « non trouvé ».
