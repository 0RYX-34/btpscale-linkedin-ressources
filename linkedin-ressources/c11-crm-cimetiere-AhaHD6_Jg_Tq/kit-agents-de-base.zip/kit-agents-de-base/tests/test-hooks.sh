#!/bin/bash
# test-hooks.sh : un verrou se prouve par un refus observé.
cd "$(dirname "$0")/../vault" || exit 1
ko=0
essai() {  # essai <hook> <json> <code attendu>
  printf '%s' "$2" | bash ".claude/hooks/$1" 2>/dev/null; code=$?
  if [ "$code" = "$3" ]; then echo "ok   $1 -> $code : $2"
  else echo "ÉCHEC $1 -> $code (attendu $3) : $2"; ko=1; fi
}
essai garde-fou.sh '{"tool_input":{"command":"git push --force origin main"}}' 2
essai garde-fou.sh '{"tool_input":{"command":"git reset --hard HEAD~1"}}' 2
essai garde-fou.sh '{"tool_input":{"command":"cat .env"}}' 2
essai garde-fou.sh '{"tool_input":{"command":"git status"}}' 0
essai vault-a-deux.sh '{"tool_input":{"file_path":"Journal/2026-09-12 Camille.md"}}' 2
essai vault-a-deux.sh '{"tool_input":{"file_path":"Décisions.md"}}' 2
essai vault-a-deux.sh '{"tool_input":{"file_path":"Propositions Alex/note.md"}}' 0
exit $ko
