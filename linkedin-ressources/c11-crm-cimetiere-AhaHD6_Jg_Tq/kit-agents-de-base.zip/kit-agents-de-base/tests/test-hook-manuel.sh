# Un verrou se prouve par un refus observé.
printf '{"tool_input":{"command":"git push --force"}}' \
  | bash .claude/hooks/garde-fou.sh ; echo "code $?"
# attendu : Refusé par garde-fou.sh : git push --force
#           code 2

printf '{"tool_input":{"command":"git status"}}' \
  | bash .claude/hooks/garde-fou.sh ; echo "code $?"
# attendu : code 0

printf '{"tool_input":{"file_path":"Journal/2026-09-12 Camille.md"}}' \
  | bash .claude/hooks/vault-a-deux.sh ; echo "code $?"
# attendu : Refusé : note de Camille. […]   code 2
