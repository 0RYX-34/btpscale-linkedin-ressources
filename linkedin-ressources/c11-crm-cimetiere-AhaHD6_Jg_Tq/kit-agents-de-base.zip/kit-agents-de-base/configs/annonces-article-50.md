# Article 50 : la première phrase, écrite et conservée.

Téléphone (agent vocal) :
« Bonjour, je suis l'assistant automatique de
<Entreprise>. Je ne suis pas une personne. Souhaitez-
vous qu'un conseiller vous rappelle ? »

Chat sur le site :
« Vous parlez à un assistant automatisé. Un humain
reprend la conversation sur demande. »

E-mail ou page rédigés avec une IA, relus :
« Texte préparé avec une IA, relu et validé
par <Prénom>, le <date>. »
