# FACTS.md : les faits du client. Neuf champs bloquants.

- [ ] Raison sociale et SIRET
- [ ] Assurance décennale : assureur, n°, validité
- [ ] Téléphone et e-mail affichés
- [ ] Adresse du siège
- [ ] Zone : codes postaux servis
- [ ] Métiers, dans les mots du client
- [ ] Délais réellement tenus (3 chantiers datés)
- [ ] Mentions légales : statut, TVA, médiateur,
      hébergeur
- [ ] Photos : 12 chantiers réels, avec la date

Preuve sociale, non bloquante mais datée :
- avis : texte, source, date (5 au moins)
Rien ne se fabrique tant qu'une case est vide.
