# Grille de marché : <marché>

| Critère    | Mesure                 | Source | Verd. |
|------------|------------------------|--------|-------|
| Douleur    | <n témoignages>        | <forum>|       |
| Pouvoir    | <marge %, qui décide>  | <inst.>|       |
| Ciblage    | <n entreprises, coût   | <reg.> |       |
|            |  d'un contact>         |        |       |
| Croissance | <% sur 3 ans> ; si     | <rapp.>|       |
|            |  rouge : équipement %  |        |       |

Verdict : vert, moyen ou rouge, avec la date de
la source. Un critère rouge n'élimine pas ;
un critère sans mesure, si.

Décisions sorties de la grille :
- <vocabulaire imposé ou interdit>
- <canal de prospection>
- <argument à ne jamais utiliser>
