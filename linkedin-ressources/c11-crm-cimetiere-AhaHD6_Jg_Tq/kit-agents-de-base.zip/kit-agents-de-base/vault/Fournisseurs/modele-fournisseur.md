# Fournisseur : <outil>

- Remplace : <l'outil payant écarté, et son prix>.
- Version libre : <nom, licence>. Hébergement : <où, €/mois>.
- API ou ligne de commande : <oui / non>. Sans API, pas d'outil.
- Compte au nom de : <l'entreprise>. Fondateurs invités.
- Preuve faite le : <date> : <un vrai rendez-vous, un vrai document signé>.
- Données : <où elles vivent, comment on les exporte>.
