# Objectifs

- Cap : <une phrase, un chiffre, une date>.
- Mesure de la semaine : <appels passés, rendez-vous pris, demandes comptées>.
- Ce qui passe avant tout : <ex. : un client signé avant tout chantier interne>.
