# Environnement

- Machine : <macOS / Windows / Linux>, terminal <zsh / bash / PowerShell>.
- Agent : <Claude Code / Codex>, version <x>.
- Outils installés : <git, python3, node, gh…>.
- Accès : <CRM, hébergeur, réseaux> ; les clés vivent dans <fichier hors du vault>, jamais ici.
- Ce qui n'est pas installé : <liste>, pour que l'agent ne le suppose pas.
