# Projet : <nom>

## État (date)
<Une phrase : où on en est.>

## Décisions
- <date> : <décision, et pourquoi>.

## Problèmes ouverts
- <ce qui bloque, depuis quand, qui doit trancher>.

## Prochaine étape
- <une action, vérifiable par une commande ou un comptage>.
