# Instructions de l'agent

Lis d'abord, dans cet ordre :
00-Qui-on-est.md, 01-Objectifs.md,
02-Environnement.md, 03-Règles.md.

Avant tout travail : reformule la demande en une
phrase, liste les étapes, puis exécute.

Un process se trouve dans Process/<nom>.md.
Suis-le ; s'il manque, dis-le, ne l'invente pas.

Interdit sans un humain : dépenser, envoyer à un
tiers, publier, supprimer, créer un compte.

Les chiffres sortent d'un script, jamais de toi.

Fin de tâche : note l'état, les décisions et les
problèmes ouverts dans Projets/<nom>.md.
