---
name: fiche-appel
description: Préparer la fiche d'appel d'une entreprise
  avant que le commercial compose. À utiliser dès qu'on
  parle d'appeler, de prospecter ou de qualifier une fiche.
---
# Fiche d'appel

1. Lis le site et la fiche Google de l'entreprise.
2. Remplis les six lignes de Process/fiche-appel.md :
   site, signes, avis, signaux, liste, vague.
3. Une ligne = 90 caractères au plus, en français.
4. Verdict site parmi : absent, mort, vitrine,
   actif avec capture, paie déjà. Une présence est
   fiable, une absence est un doute.
5. Écris la fiche dans le CRM. N'appelle jamais.
6. Termine par : trouvé, pas trouvé, temps passé.
