---
name: relance-demande
description: Rédiger les relances J+2 et J+7 d'une demande
  non rappelée, au nom de l'artisan. L'agent prépare,
  l'humain envoie.
---
# Relance d'une demande

1. Lis Process/rappel-demande.md et la demande :
   prénom, pièce, date de réception, dernier contact.
2. Si la demande a moins de 2 jours : rien à envoyer.
3. Sinon, rédige le message J+2 ou J+7 en remplaçant
   <pièce>, <Prénom>, <Entreprise>, <numéro>.
4. Jamais le mot « IA », jamais de prix, jamais de délai
   que l'artisan n'a pas donné.
5. Dépose le texte dans A-envoyer/<date>-<prénom>.md.
   N'envoie rien : l'artisan ou l'agence appuie.
