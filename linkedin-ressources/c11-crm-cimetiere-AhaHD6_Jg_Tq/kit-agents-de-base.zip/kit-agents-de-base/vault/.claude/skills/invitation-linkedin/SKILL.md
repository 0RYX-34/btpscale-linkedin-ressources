---
name: invitation-linkedin
description: Rédiger une invitation LinkedIn de 200
  caractères et le premier message après acceptation,
  à partir de la fiche d'un prospect. Jamais d'envoi.
---
# Invitation LinkedIn

1. Lis la fiche du prospect : métier, ville, site,
   ce qu'il a publié récemment.
2. Invitation : 200 caractères au plus, une raison
   vraie de se connecter, aucune offre, aucun « IA ».
3. Message après acceptation : 3 phrases, une
   question sur son activité, pas de lien.
4. Écris trois variantes, l'humain en choisit une.
5. Dépose dans A-envoyer/linkedin-<date>.md.
   Aucune invitation ni message n'est envoyé par toi :
   les conditions de LinkedIn l'interdisent (§ 8.2).
