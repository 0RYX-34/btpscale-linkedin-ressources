#!/bin/bash
# garde-fou.sh : refuse les commandes interdites.
# Claude Code envoie la commande en JSON sur stdin ;
# le code de retour 2 bloque et explique le refus.
cmd=$(python3 -c 'import json, sys
d = json.load(sys.stdin).get("tool_input", {})
print(d.get("command", ""))')
case "$cmd" in
  *"push --force"*|*"push -f"*|*"reset --hard"*|\
  *"git clean"*|*"branch -D"*|*".env"*|\
  *"keystore"*|*"rm -rf"*)
    echo "Refusé par garde-fou.sh : $cmd" >&2
    exit 2 ;;
esac
exit 0
