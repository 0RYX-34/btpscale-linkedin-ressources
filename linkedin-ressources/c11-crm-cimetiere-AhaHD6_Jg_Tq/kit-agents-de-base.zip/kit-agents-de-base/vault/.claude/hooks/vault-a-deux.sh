#!/bin/bash
# vault-a-deux.sh : refuse d'écrire chez l'autre.
AUTRE="Camille"   # le prénom de l'autre fondateur
f=$(python3 -c 'import json, sys
d = json.load(sys.stdin).get("tool_input", {})
print(d.get("file_path", ""))')
case "$f" in
  *"Propositions $AUTRE"*|*"Journal/"*"$AUTRE"*|\
  *"Tâches/$AUTRE"*|*"Décisions.md")
    echo "Refusé : note de $AUTRE." >&2
    echo "Écris dans Inbox/Pour $AUTRE.md" >&2
    exit 2 ;;
esac
exit 0
