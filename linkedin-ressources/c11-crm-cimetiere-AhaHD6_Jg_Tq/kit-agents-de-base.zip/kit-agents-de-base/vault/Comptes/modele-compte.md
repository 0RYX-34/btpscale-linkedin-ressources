# Compte : <plateforme>

- Créé par : <prénom>, à la main, depuis <son ordinateur / téléphone>.
- Le : <AAAA-MM-JJ>. Sans VPN, sans navigateur automatisé.
- Adresse rattachée : <adresse dédiée>, jamais l'adresse principale.
- Double authentification : <oui, méthode>.
- Codes de récupération : <où, hors du vault>.
- Deuxième personne qui sait y entrer : <prénom>.
- Conditions cachées connues : <ex. : 2 relations avant une page>.
