# Règles du vault à deux

1. Chacun écrit chez lui : Propositions <Prénom>/,
   Journal/<date> <Prénom>.md, Tâches/<Prénom>.md.
2. Une note de l'autre ne se réécrit jamais. On répond
   dans sa section « ## Commentaires <Prénom> », en bas.
3. Décisions.md : décidées à deux, écrites par une main.
4. Un chantier de plus de 30 minutes prend un verrou,
   une ligne en haut de En cours.md :
   - [ ] 2026-09-12 · <Prénom> (agent) · <sujet> ·
     notes touchées : <liste>
   Si l'autre tient le sujet : Inbox/Pour <Prénom>.md.
5. Pour se parler : un message, jamais une note glissée.
6. Rien ne se supprime ni ne se renomme : on archive.

Le hook .claude/hooks/vault-a-deux.sh refuse l'écriture
dans les notes de l'autre. Un verrou se prouve
par un refus.
