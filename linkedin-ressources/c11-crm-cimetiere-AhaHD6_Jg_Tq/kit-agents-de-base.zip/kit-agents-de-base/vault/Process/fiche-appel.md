# Process : fiche d'appel

Question de départ : que dois-je savoir avant de
composer le numéro ? Tout le reste sort de la fiche.

| Ligne | Contenu (90 caractères au plus)              |
|-------|----------------------------------------------|
| 1 Site | absent · mort · vitrine · actif · paie déjà |
| 2 Signes | formulaire, avis récents, pages ville/métier, tel visible |
| 3 Avis | nombre, note, date du dernier                |
| 4 Signaux | zone, métier, taille, dirigeant nommé     |
| 5 Liste | liste-<ville>-<département>-<AAAA-MM-JJ>    |
| 6 Vague | 1 = site absent ou faible · 2 = le reste     |

Sources : registre des entreprises (sièges, pas
établissements), fiche Google, annuaires, le site lu.
La machine remplit. Le commercial note le résultat.
