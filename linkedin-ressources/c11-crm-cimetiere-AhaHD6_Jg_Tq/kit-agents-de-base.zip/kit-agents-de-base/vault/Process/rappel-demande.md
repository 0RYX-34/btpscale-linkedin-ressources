# Process : rappeler une demande

Règle d'or : 5 minutes. Plancher : 1 heure entre 8 h
et 19 h. Nuit et week-end : avant midi le jour ouvré
suivant.

## Message quand on ne peut pas décrocher (10 s)
« Bonjour, j'ai bien reçu votre demande pour votre
<pièce>. Je suis sur un chantier, je vous rappelle
ce soir entre 18 h et 19 h. <Prénom>, <Entreprise>. »

## Relance J+2 (SMS ou e-mail, au nom de l'artisan)
« Bonjour, c'est <Prénom> de <Entreprise>. Votre
projet de <pièce> est-il toujours d'actualité ?
Répondez OUI et je vous rappelle. »

## Relance J+7, la dernière
« Bonjour, dernier message de ma part pour votre
<pièce>. Si le moment n'est pas le bon, gardez mon
numéro : <numéro>. Bonne journée. <Prénom> »

OUI = alerte immédiate. Rendez-vous, refus ou STOP
= arrêt. Après J+7, on n'écrit plus.
