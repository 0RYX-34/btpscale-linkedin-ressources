# Fiche de palier : <nom du process>

- Entrée : <ce qui arrive : mail, fichier, formulaire>
- Sortie : <ce qui doit exister à la fin>
- Mesure métier : <appels, rendez-vous, demandes…>
- Irréversible dedans : <dépense, envoi, suppression>

| Palier | Condition pour y passer         | Fait le |
|--------|---------------------------------|---------|
| 0 main | fait deux fois, trace gardée    |         |
| 1 script | la partie déterministe isolée | |
| 2 supervisé | un humain relit chaque sortie | |
| 3 planifié | deux passages sans surprise au 2 | |

Exécutions à la main : 0 / 2
Temps par exécution : <min>
Coût par résultat au palier 2 : <€>
