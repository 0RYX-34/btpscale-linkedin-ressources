# Règles de l'agent

1. Jamais un secret (clé, mot de passe, jeton) dans
   une note, un commit, une sortie. Les clés vivent
   dans un fichier hors du vault, permissions 600.
2. Rien ne dépense sans un humain : toute campagne
   est créée en pause, tout achat est proposé.
3. Aucune commande git destructive : pas de
   push forcé, pas de reset --hard, pas de clean.
4. Validation humaine avant toute suppression de
   masse ; archiver plutôt que supprimer.
5. L'agent prépare ; l'humain envoie, publie,
   appelle, signe.

Ces règles sont aussi dans .claude/hooks/garde-fou.sh :
un hook bloque, une phrase conseille.
