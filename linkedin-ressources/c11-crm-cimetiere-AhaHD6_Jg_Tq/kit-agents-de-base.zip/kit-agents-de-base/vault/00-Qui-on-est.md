# Qui on est

- Entreprise : <nom>. Deux fondateurs : <prénom>, <prénom>.
- On vend : <une phrase, sans jargon>.
- À qui : <le client type, sa taille, sa zone>.
- Ce qu'on refuse : <ex. : promettre un chiffre sans preuve>.
- Vocabulaire : on dit « <mot du client> », jamais « <mot interne> ».
