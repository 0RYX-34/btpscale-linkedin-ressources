# cout.py : coût d'une boucle d'agent, par résultat.
# Journal : une ligne JSON par passage, par exemple
# {"modele":"sonnet","entree":120000,"sortie":9000,
#  "cache":80000,"resultats":3}
import json, sys
PRIX = {  # $ par million de tokens, 12/09/2026
    "opus":   {"entree": 5, "sortie": 25},
    "sonnet": {"entree": 2, "sortie": 10},
    "haiku":  {"entree": 1, "sortie": 5}}
total, resultats = 0.0, 0
for l in open(sys.argv[1]):
    p = json.loads(l)
    t = PRIX[p["modele"]]
    cache = p.get("cache", 0) * t["entree"] * 0.1
    cout = (p["entree"] * t["entree"]
            + p["sortie"] * t["sortie"] + cache) / 1e6
    total += cout
    resultats += p.get("resultats", 0)
    print(f'{p["modele"]:7} {cout:6.2f} $  '
          f'{p.get("resultats", 0)} résultat(s)')
print(f'total {total:.2f} $ pour {resultats} résultats')
par = total / max(resultats, 1)
print(f'coût par résultat : {par:.2f} $')
