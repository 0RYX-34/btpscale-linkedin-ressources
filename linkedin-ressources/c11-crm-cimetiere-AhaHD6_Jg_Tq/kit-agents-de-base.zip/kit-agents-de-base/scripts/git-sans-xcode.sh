# Sur un Mac sans droits admin, git réclame Xcode.
# Contournement : le git embarqué de GitHub Desktop.
npm install dugite          # dans un dossier outils
mkdir -p ~/.local/bin
cat > ~/.local/bin/git <<'EOF'
#!/bin/bash
D="$HOME/outils/node_modules/dugite/git"
export GIT_EXEC_PATH="$D/libexec/git-core"
export GIT_TEMPLATE_DIR="$D/share/git-core/templates"
exec "$D/bin/git" "$@"
EOF
chmod +x ~/.local/bin/git

# Sans git du tout : l'archive d'un dépôt privé.
gh api repos/OWNER/DEPOT/tarball/main > depot.tgz
