# sirene-filtre.py : les sièges d'une cible, depuis
# StockEtablissement_utf8.csv (data.gouv.fr).
import csv, sys
NAF = {"43.31Z", "43.32A", "43.33Z", "43.39Z", "43.22A"}
TAILLE = {"02", "03", "11"}        # 3 à 19 salariés
DEP = sys.argv[2]                  # ex. 69
n = 0
f = open(sys.argv[1], encoding="utf-8")
for e in csv.DictReader(f):
    # les sièges, pas les établissements (35 % d'écart)
    if e["etablissementSiege"] != "true":
        continue
    if e["activitePrincipaleEtablissement"] not in NAF:
        continue
    if e["trancheEffectifsEtablissement"] not in TAILLE:
        continue
    if not e["codePostalEtablissement"].startswith(DEP):
        continue
    n += 1
    nom = (e["denominationUsuelleEtablissement"]
           or e["enseigne1Etablissement"])
    print(e["siren"], e["codePostalEtablissement"], nom)
print(n, "sièges", file=sys.stderr)
