# delai-rappel.py : le seul chiffre qui dépend
# de l'artisan. demandes.csv : recue,rappelee
# (AAAA-MM-JJ HH:MM ; rappelee vide = jamais)
import csv, sys
from datetime import datetime
F = "%Y-%m-%d %H:%M"
delais, jamais = [], 0
for r in csv.DictReader(open(sys.argv[1])):
    if not r["rappelee"].strip():
        jamais += 1
        continue
    recue = datetime.strptime(r["recue"], F)
    rappel = datetime.strptime(r["rappelee"], F)
    delais.append((rappel - recue).total_seconds() / 60)
n = len(delais) + jamais
print(f"{n} demandes, {jamais} jamais rappelées")
if delais:
    mediane = sorted(delais)[len(delais) // 2]
    print(f"délai médian : {mediane:.0f} min")
    print(f"sous 5 min : {sum(d <= 5 for d in delais)}")
    tard = sum(d > 1440 for d in delais)
    print(f"après 24 h : {tard}")
