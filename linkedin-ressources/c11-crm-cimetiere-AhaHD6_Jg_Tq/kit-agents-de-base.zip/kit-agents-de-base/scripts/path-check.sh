# npm -g installe hors du PATH : lier, puis vérifier.
export PATH="$HOME/.local/bin:$PATH"   # dans ~/.zshrc
ln -sf ~/.npm-global/bin/vercel ~/.local/bin/vercel
ln -sf ~/.npm-global/bin/opencli ~/.local/bin/opencli

# Quatre contrôles après l'installation :
which git && git --version   # la bonne version répond
which vercel opencli         # chaque binaire trouvé
gh repo view OWNER/DEPOT     # le dépôt privé répond
printf '{"tool_input":{"command":"git push --force"}}' \
  | bash .claude/hooks/garde-fou.sh   # refus observé
