# Kit d'agents de base — BTPScale, 12 septembre 2026

Les fichiers montrés dans les ressources LinkedIn de Selam Gasc, en version complète.
Rien de personnel dedans : à copier, adapter, faire tourner.

## Monter la base en une soirée

1. Créer un dossier `vault/`, l'ouvrir dans Obsidian.
2. Écrire les quatre notes de base : `00-Qui-on-est.md`, `01-Objectifs.md`,
   `02-Environnement.md`, `03-Règles.md`. En français, sans jargon.
3. Installer un agent en ligne de commande (Claude Code ou Codex). Son fichier
   d'instructions : `CLAUDE.md` pour Claude Code, `AGENTS.md` pour Codex, même contenu.
4. Mettre les clés dans un fichier hors du vault, permissions fermées (`chmod 600`).
5. Copier `.claude/` (hooks, réglages, skills) à la racine du vault et rendre les hooks
   exécutables : `chmod +x .claude/hooks/*.sh`.
6. Prouver un verrou par un refus : `bash tests/test-hooks.sh`.

## Automatiser un process, par paliers

- Écrire le process dans `Process/<nom>.md`. Le faire exécuter par l'agent deux fois,
  en regardant (`prompts/premiere-execution.md`).
- Après deux réussites : en faire un skill (`.claude/skills/<nom>/SKILL.md`).
- Sortir les chiffres dans un script (`scripts/`).
- Planifier seulement ce qui a tourné deux fois sans surprise (`scripts/cron-exemple.txt`).

## Contenu

- `vault/` : les quatre notes, `CLAUDE.md`, `Process/`, `Projets/`, `Comptes/`, `Fournisseurs/`,
  `Règles du vault à deux.md`, `.claude/` (réglages, deux hooks, trois skills).
- `prompts/` : première exécution, agent supervisé, grille de marché, verdict de site,
  contrôle avant mise en ligne, alternative libre, invitations LinkedIn, audit article 50.
- `scripts/` : `cout.py`, `delai-rappel.py`, `sirene-filtre.py`, `cron-exemple.txt`,
  `git-sans-xcode.sh`, `path-check.sh`, avec des données d'exemple dans `exemples/`.
- `configs/` : `client-config.yml`, `FACTS.md`, `grille-marche.md`, `fiche-crm.txt`,
  `annonces-article-50.md`.
- `tests/test-hooks.sh` : les refus attendus des deux hooks.

Les hooks suivent le contrat de Claude Code : commande ou chemin reçus en JSON sur l'entrée
standard, code de retour 2 pour bloquer. Codex lit le même `AGENTS.md` mais n'a pas ces hooks.
